-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2020 at 08:42 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nba`
--

-- --------------------------------------------------------

--
-- Table structure for table `teams_info`
--

CREATE TABLE `teams_info` (
  `team_id` int(2) NOT NULL,
  `team_name` varchar(24) DEFAULT NULL,
  `team_short_name` varchar(3) DEFAULT NULL,
  `years` int(2) DEFAULT NULL,
  `total_games` int(4) DEFAULT NULL,
  `total_wins` int(4) DEFAULT NULL,
  `total_losses` int(4) DEFAULT NULL,
  `champions` int(2) DEFAULT NULL,
  `other_names` varchar(122) DEFAULT NULL,
  `active` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teams_info`
--

INSERT INTO `teams_info` (`team_id`, `team_name`, `team_short_name`, `years`, `total_games`, `total_wins`, `total_losses`, `champions`, `other_names`, `active`) VALUES
(1, 'Atlanta Hawks', 'ATL', 71, 5609, 2762, 2847, 1, '[\'Atlanta Hawks\', \'St. Louis Hawks\', \'Milwaukee Hawks\', \'Tri-Cities Blackhawks\']', 'TRUE'),
(2, 'Boston Celtics', 'BOS', 74, 5778, 3416, 2362, 17, '[\'Boston Celtics\']', 'TRUE'),
(3, 'Brooklyn Nets', 'NJN', 53, 4276, 1849, 2427, 2, '[\'Brooklyn Nets\', \'New Jersey Nets\', \'New York Nets\', \'New York Nets\', \'New Jersey Americans\']', 'TRUE'),
(4, 'Charlotte Hornets', 'CHA', 30, 2385, 1046, 1339, 0, '[\'Charlotte Hornets\', \'Charlotte Bobcats\', \'Charlotte Hornets\']', 'TRUE'),
(5, 'Chicago Bulls', 'CHI', 54, 4353, 2224, 2129, 6, '[\'Chicago Bulls\']', 'TRUE'),
(6, 'Cleveland Cavaliers', 'CLE', 50, 4024, 1862, 2162, 1, '[\'Cleveland Cavaliers\']', 'TRUE'),
(7, 'Dallas Mavericks', 'DAL', 40, 3205, 1605, 1600, 1, '[\'Dallas Mavericks\']', 'TRUE'),
(8, 'Denver Nuggets', 'DEN', 53, 4277, 2154, 2123, 0, '[\'Denver Nuggets\', \'Denver Nuggets\', \'Denver Rockets\']', 'TRUE'),
(9, 'Detroit Pistons', 'DET', 72, 5672, 2752, 2920, 3, '[\'Detroit Pistons\', \'Fort Wayne Pistons\']', 'TRUE'),
(10, 'Golden State Warriors', 'GSW', 74, 5776, 2784, 2992, 6, '[\'Golden State Warriors\', \'San Francisco Warriors\', \'Philadelphia Warriors\']', 'TRUE'),
(11, 'Houston Rockets', 'HOU', 53, 4271, 2260, 2011, 2, '[\'Houston Rockets\', \'San Diego Rockets\']', 'TRUE'),
(12, 'Indiana Pacers', 'IND', 53, 4276, 2203, 2073, 3, '[\'Indiana Pacers\', \'Indiana Pacers\']', 'TRUE'),
(13, 'Los Angeles Clippers', 'LAC', 50, 4025, 1647, 2378, 0, '[\'Los Angeles Clippers\', \'San Diego Clippers\', \'Buffalo Braves\']', 'TRUE'),
(14, 'Los Angeles Lakers', 'LAL', 72, 5668, 3374, 2294, 16, '[\'Los Angeles Lakers\', \'Minneapolis Lakers\']', 'TRUE'),
(15, 'Memphis Grizzlies', 'MEM', 25, 1975, 820, 1155, 0, '[\'Memphis Grizzlies\', \'Vancouver Grizzlies\']', 'TRUE'),
(16, 'Miami Heat', 'MIA', 32, 2549, 1329, 1220, 3, '[\'Miami Heat\']', 'TRUE'),
(17, 'Milwaukee Bucks', 'MIL', 52, 4189, 2176, 2013, 1, '[\'Milwaukee Bucks\']', 'TRUE'),
(18, 'Minnesota Timberwolves', 'MIN', 31, 2465, 977, 1488, 0, '[\'Minnesota Timberwolves\']', 'TRUE'),
(19, 'New Orleans Pelicans', 'NOH', 18, 1433, 666, 767, 0, '[\'New Orleans Pelicans\', \'NO/Ok. City Hornets\', \'New Orleans Hornets\']', 'TRUE'),
(20, 'New York Knicks', 'NYK', 74, 5776, 2795, 2981, 2, '[\'New York Knicks\']', 'TRUE'),
(21, 'Oklahoma City Thunder', 'OKC', 53, 4271, 2316, 1955, 1, '[\'Oklahoma City Thunder\', \'Seattle SuperSonics\']', 'TRUE'),
(22, 'Orlando Magic', 'ORL', 31, 2467, 1182, 1285, 0, '[\'Orlando Magic\']', 'TRUE'),
(23, 'Philadelphia 76ers', 'PHI', 71, 5606, 2892, 2714, 3, '[\'Philadelphia 76ers\', \'Syracuse Nationals\']', 'TRUE'),
(24, 'Phoenix Suns', 'PHO', 52, 4189, 2208, 1981, 0, '[\'Phoenix Suns\']', 'TRUE'),
(25, 'Portland Trail Blazers', 'POR', 50, 4026, 2159, 1867, 1, '[\'Portland Trail Blazers\']', 'TRUE'),
(26, 'Sacramento Kings', 'SAC', 72, 5670, 2584, 3086, 1, '[\'Sacramento Kings\', \'Kansas City Kings\', \'Kansas City-Omaha Kings\', \'Cincinnati Royals\', \'Rochester Royals\']', 'TRUE'),
(27, 'San Antonio Spurs', 'SAS', 53, 4276, 2563, 1713, 5, '[\'San Antonio Spurs\', \'San Antonio Spurs\', \'Texas Chaparrals\', \'Dallas Chaparrals\']', 'TRUE'),
(28, 'Toronto Raptors', 'TOR', 25, 1975, 942, 1033, 1, '[\'Toronto Raptors\']', 'TRUE'),
(29, 'Utah Jazz', 'UTA', 46, 3696, 2000, 1696, 0, '[\'Utah Jazz\', \'New Orleans Jazz\']', 'TRUE'),
(30, 'Washington Wizards', 'WAS', 59, 4750, 2148, 2602, 1, '[\'Washington Wizards\', \'Washington Bullets\', \'Capital Bullets\', \'Baltimore Bullets\', \'Chicago Zephyrs\', \'Chicago Packers\']', 'TRUE'),
(31, 'Anderson Packers', 'AND', 1, 64, 37, 27, 0, '[\'Anderson Packers\']', 'FALSE'),
(32, 'Baltimore Bullets', 'BLB', 8, 450, 158, 292, 1, '[\'Baltimore Bullets\']', 'FALSE'),
(33, 'Chicago Stags', 'CHS', 4, 237, 145, 92, 0, '[\'Chicago Stags\']', 'FALSE'),
(34, 'Cleveland Rebels', 'CLR', 1, 60, 30, 30, 0, '[\'Cleveland Rebels\']', 'FALSE'),
(35, 'Denver Nuggets', 'DNN', 1, 62, 11, 51, 0, '[\'Denver Nuggets\']', 'FALSE'),
(36, 'Detroit Falcons', 'DTF', 1, 60, 20, 40, 0, '[\'Detroit Falcons\']', 'FALSE'),
(37, 'Indianapolis Jets', 'INJ', 1, 60, 18, 42, 0, '[\'Indianapolis Jets\']', 'FALSE'),
(38, 'Indianapolis Olympians', 'INO', 4, 269, 132, 137, 0, '[\'Indianapolis Olympians\']', 'FALSE'),
(39, 'Kentucky Colonels', 'KEN', 9, 744, 448, 296, 1, '[\'Kentucky Colonels\']', 'FALSE'),
(40, 'Memphis Sounds', 'MMS', 8, 660, 275, 385, 0, '[\'Memphis Sounds\', \'Memphis Tams\', \'Memphis Pros\', \'New Orleans Buccaneers\']', 'FALSE'),
(41, 'Pittsburgh Condors', 'PTC', 5, 408, 180, 228, 1, '[\'Pittsburgh Condors\', \'Minnesota Pipers\', \'Pittsburgh Pipers\']', 'FALSE'),
(42, 'Pittsburgh Ironmen', 'PIT', 1, 60, 15, 45, 0, '[\'Pittsburgh Ironmen\']', 'FALSE'),
(43, 'Providence Steam Rollers', 'PRO', 3, 168, 46, 122, 0, '[\'Providence Steam Rollers\']', 'FALSE'),
(44, 'San Diego Sails', 'SDS', 4, 263, 101, 162, 0, '[\'San Diego Sails\', \'San Diego Conquistadors\']', 'FALSE'),
(45, 'Sheboygan Red Skins', 'SHE', 1, 62, 22, 40, 0, '[\'Sheboygan Red Skins\']', 'FALSE'),
(46, 'Spirits of St. Louis', 'SSL', 9, 744, 334, 410, 0, '[\'Spirits of St. Louis\', \'Carolina Cougars\', \'Houston Mavericks\']', 'FALSE'),
(47, 'St. Louis Bombers', 'STB', 4, 237, 122, 115, 0, '[\'St. Louis Bombers\']', 'FALSE'),
(48, 'The Floridians', 'FLO', 5, 408, 189, 219, 0, '[\'The Floridians\', \'Miami Floridians\', \'Minnesota Muskies\']', 'FALSE'),
(49, 'Toronto Huskies', 'TRH', 1, 60, 22, 38, 0, '[\'Toronto Huskies\']', 'FALSE'),
(50, 'Utah Stars', 'UTS', 9, 676, 366, 310, 1, '[\'Utah Stars\', \'Los Angeles Stars\', \'Anaheim Amigos\']', 'FALSE'),
(51, 'Virginia Squires', 'VIR', 9, 743, 326, 417, 1, '[\'Virginia Squires\', \'Washington Capitols\', \'Oakland Oaks\']', 'FALSE'),
(52, 'Washington Capitols', 'WSC', 5, 271, 157, 114, 0, '[\'Washington Capitols\']', 'FALSE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teams_info`
--
ALTER TABLE `teams_info`
  ADD PRIMARY KEY (`team_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
